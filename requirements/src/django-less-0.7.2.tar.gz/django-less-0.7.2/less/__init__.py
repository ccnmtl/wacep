

class LessException(Exception):
    pass
